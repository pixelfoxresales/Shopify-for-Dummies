---
name: ❓ Support Question
about: I think I don't understand how to do something 🤨
---

<!-- ---------- 👆 Click "Preview"! -->

Issues on GitHub are intended to be related to problems and feature requests so we ask you not use
issues to ask for support.

---

## ❓ Gatsby Storefront Resources

- Github - https://github.com/gatsbystorefront
- Demo - https://demo.gatsbystorefront.com/
- Spectrum community - https://spectrum.chat/gatsbystorefront

**ISSUES WHICH ARE QUESTIONS WILL BE CLOSED**
