// This allows Gatsby to resolve the theme since Node automatically looks for index.js.
