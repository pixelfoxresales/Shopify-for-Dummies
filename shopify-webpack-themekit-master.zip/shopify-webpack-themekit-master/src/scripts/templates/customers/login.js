/**
 * Customers/Login Template Script
 * ------------------------------------------------------------------------------
 * A file that contains scripts highly couple code to the Customers/Login template.
 *
 * @namespace login
 * @file vendors@template.collection.js
 * @file template.collection.js
 *
 */
