/**
 * Index Template Script
 * ------------------------------------------------------------------------------
 * A file that contains scripts highly couple code to the Index/Home template.
 *
 * @namespace index
 * @file vendors@template.index.js
 * @file template.index.js
 *
 */
