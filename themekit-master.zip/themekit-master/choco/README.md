﻿# Themekit Chocolatey Package

This is the chocolatey package source for themekit

## Update installations instructions

For instructions on how to update the package please refer to the CONTRIBUTING.md file for full distribution instructions.
